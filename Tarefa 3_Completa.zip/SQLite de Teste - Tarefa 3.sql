SELECT
    RegistroANS,
    RazaoSocial,
    UF
FROM operadoras
LIMIT 5;
