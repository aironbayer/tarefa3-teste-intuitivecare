SELECT
    DATA,
    RegistroANS,
    RazaoSocial,
    UF,
    Trimestre,
    Ano,
    ValorDespesas
FROM consolidado_enriquecido
LIMIT 5;
